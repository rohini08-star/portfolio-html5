document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("contactForm");

    if (!form) {
        return;
    }


    form.addEventListener("submit", function (event) {

        event.preventDefault();


        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const message = document.getElementById("message");

        const nameError = document.getElementById("name-error");
        const emailError = document.getElementById("email-error");
        const messageError = document.getElementById("message-error");

        const formStatus = document.getElementById("form-status");


        nameError.textContent = "";
        emailError.textContent = "";
        messageError.textContent = "";
        formStatus.textContent = "";


        let isValid = true;


        /* Name validation */

        if (name.value.trim() === "") {

            nameError.textContent = "Please enter your name.";

            isValid = false;

        }


        /* Email validation */

        if (email.value.trim() === "") {

            emailError.textContent = "Please enter your email address.";

            isValid = false;

        }
        else if (!email.validity.valid) {

            emailError.textContent =
                "Please enter a valid email address.";

            isValid = false;

        }


        /* Message validation */

        if (message.value.trim() === "") {

            messageError.textContent =
                "Please enter your message.";

            isValid = false;

        }


        /* Final result */

        if (isValid) {

            formStatus.textContent =
                "Thank you! Your message has been validated successfully.";

            form.reset();

        }

    });

});